$(document).ready(function() {
    let links = $('.navbar-nav li a');

    links.forEach(link => {
        console.log(link);
    });
});