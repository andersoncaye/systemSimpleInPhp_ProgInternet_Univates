    <!-- Meta tags Obrigatórias -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>

    <!-- -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <!-- <link href="https://fonts.googleapis.com/css?family=Raleway:400,500,500i,700,800i" rel="stylesheet"> -->
    <link href="https://fonts.googleapis.com/css?family=Ubuntu&display=swap" rel="stylesheet">

    <!-- reference your copy Font Awesome here (from our CDN or by hosting yourself) -->
    <link href="assets/css/fontawesome-free-5.9.0-web/css/fontawesome.css" rel="stylesheet">
    <link href="assets/css/fontawesome-free-5.9.0-web/css/brands.css" rel="stylesheet">
    <link href="assets/css/fontawesome-free-5.9.0-web/css/solid.css" rel="stylesheet">

    <!-- Lacaweb -->
<!--    <link href="assets/css/edge/stylesheets/locastyle.css" rel="stylesheet">-->
<!--    Documentação: http://opensource.locaweb.com.br/ -->
<!--    http://opensource.locaweb.com.br/locawebstyle-v2/manual/introducao/como-usar/-->

    <!-- CSS -->
    <link href="assets/css/style.css" rel="stylesheet" type="text/css"/>

    <title>CB Factory | By Anderson Caye and Bruno Bencke</title>