<footer>
    <div class="container">
        <p class="d-block text-center text-white-50 m-0"> System and Layout - Anderson Caye & Bruno Bencke - 2019 <br> Cadeira de Programação para Internet - Univates/RS | Professor Alexandre Wolf </p>
    </div>
</footer>